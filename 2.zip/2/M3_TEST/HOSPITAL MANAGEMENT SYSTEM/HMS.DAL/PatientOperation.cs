﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HMS.ENTITY;   //Reference to Entity Library
using HMS.EXCEPTION;   //Reference to Exeption Library
using System.Data.SqlClient;
using System.Data;
using System.Configuration;

namespace HMS.DAL
{
    /// <summary>
    /// patientloyee ID : 161261
    /// patientloyee Name : Preetha Senthilkumar
    /// Description : This class will provide the CRUD operations for the patient(DAL LIBRARY)
    /// Date of Creation : 17.10.2018
    /// </summary>
    public class PatientOperation
    {

        static string patientConnStr = ConfigurationManager.ConnectionStrings["conStr"].ToString();
        static SqlConnection patientConnObj=new SqlConnection();
        SqlCommand patientCommand;
        DataTable dtDept, dtpatient;
        SqlDataReader patientReader = null;

        public PatientOperation()
        {
            patientConnObj = new SqlConnection();
            patientConnObj.ConnectionString = patientConnStr;
        }

        //public DataTable LoadDeparment()
        //{

        //    try
        //    {
        //        dtDept = new DataTable();
        //        patientCommand = new SqlCommand("Preetha.usp_DisplayPatientProcedure", patientConnObj);
        //        patientCommand.CommandType = CommandType.StoredProcedure;
        //        patientConnObj.Open();
        //        patientReader = patientCommand.ExecuteReader();
        //        dtDept.Load(patientReader);

        //    }
        //    catch (SqlException)
        //    {
        //        throw;

        //    }
        //    catch (Exception)
        //    {

        //        throw;
        //    }
        //    finally
        //    {
        //        patientReader.Close();
        //        if (patientConnObj.State == ConnectionState.Open) patientConnObj.Close();
        //    }
        //    return dtDept;
        //}

        public int AddPatient_DAL(Patient patient)
        {
            int rowsAffected = 0;
            try
            {
                //Adds the patient records into the table...
              
                patientCommand = new SqlCommand("Preetha.usp_AddPatientProcedure", patientConnObj);
                patientCommand.CommandType = CommandType.StoredProcedure;

                //Adding parameters to command
                patientCommand.Parameters.AddWithValue("@p_FirstName", patient.Patient_First_Name);
                patientCommand.Parameters.AddWithValue("@p_LastName", patient.Patient_Last_Name);
                patientCommand.Parameters.AddWithValue("@p_gender", patient.Patient_Gender);
                patientCommand.Parameters.AddWithValue("@p_Address", patient.Patient_Address);
                patientCommand.Parameters.AddWithValue("@p_City", patient.Patient_City);
                patientCommand.Parameters.AddWithValue("@p_State ", patient.Patient_State);
                patientCommand.Parameters.AddWithValue("@p_Pincode ", patient.Patient_PinCode);
                patientCommand.Parameters.AddWithValue("@p_Phone", patient.Patient_PhoneNumber);
                //Executing command
                patientConnObj.Open();
                rowsAffected = patientCommand.ExecuteNonQuery();

            }
            catch (SqlException)
            {

                throw;
            }
            catch (Exception)
            {

                throw;
            }
            finally
            {
                if (patientConnObj.State == ConnectionState.Open) patientConnObj.Close();
            }
            return rowsAffected;

        }

 
        public DataTable DisplayPatient_DAL()
        {
            //displays the aptient records..
            try
            {
                dtpatient = new DataTable();
                patientCommand = new SqlCommand("[Preetha].[usp_DisplayPatientProcedure]", patientConnObj);
                patientCommand.CommandType = CommandType.StoredProcedure;
                patientConnObj.Open();
                patientReader = patientCommand.ExecuteReader();
                if (patientReader.HasRows)
                {
                    dtpatient.Load(patientReader);
                }
            }
            catch (SqlException)
            {

                throw;
            }
            catch (Exception)
            {

                throw;
            }
            finally
            {
                patientReader.Close();
                if (patientConnObj.State == ConnectionState.Open) patientConnObj.Close();
            }
            return dtpatient;
        }
    }
}
