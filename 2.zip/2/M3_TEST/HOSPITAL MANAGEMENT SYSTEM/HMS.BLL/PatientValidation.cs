﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HMS.ENTITY;
using HMS.EXCEPTION;
using HMS.DAL;
using System.Data.SqlClient;
using System.Data;

namespace HMS.BLL
{
    public class PatientValidation
    {
        PatientOperation patientOperation;
        //public DataTable LoadDeparment_BLL()
        //{
        //    DataTable dtDept;
        //    try
        //    {
        //        patientOperation = new PatientOperation();
        //        dtDept = patientOperation.LoadDeparment();
        //    }
        //    catch (SqlException se)
        //    {

        //        throw se;
        //    }
        //    catch (Exception ex)
        //    {

        //        throw ex;
        //    }
        //    return dtDept;
        //}

        //validate patient
        public bool validatepatient(Patient newpatient)
        {
            bool isValidpatient = true;
            StringBuilder sbError = new StringBuilder();
            try
            {
                //First_Name_validation
                if (newpatient.Patient_First_Name == string.Empty)
                {
                    isValidpatient = false;
                    sbError.Append("Please enter patient first Name");
                }
                if (!isValidpatient) throw new PatientException(sbError.ToString());
                //Last_name_validation
                if (newpatient.Patient_Last_Name == string.Empty)
                {
                    isValidpatient = false;
                    sbError.Append("Please enter patient last Name");
                }
                if (!isValidpatient) throw new PatientException(sbError.ToString());
            }
            catch (PatientException ex)
            { throw ex; }

            return isValidpatient;
        }

        //Add Patient
        public int AddPatient_BLL(Patient newpatient)
        {
            int rowsAffected = 0;
            PatientOperation operationObj;
            try
            {
                if (validatepatient(newpatient))
                {
                    operationObj = new PatientOperation();
                    rowsAffected = operationObj.AddPatient_DAL(newpatient);
                }
            }
            catch (PatientException ex) { throw ex; }
            catch (SqlException se) { throw se; }
            catch (Exception ex) { throw ex; }
            return rowsAffected;

        }

        public DataTable DisplayPatient_BLL()
        {
            DataTable dtpatient;
            try
            {
                patientOperation = new PatientOperation();
                dtpatient = patientOperation.DisplayPatient_DAL();
            }
            catch (SqlException se)
            {

                throw se;
            }
            catch (Exception ex)
            {

                throw ex;
            }
            return dtpatient;
        }

        //validate Patient
        public bool validateEmp(Patient newpatient)
        {
            bool isValidEmp = true;
            StringBuilder sbError = new StringBuilder();
            try
            {
                //Checking full name...
                if (newpatient.Patient_First_Name == string.Empty)
                {
                    isValidEmp = false;
                    sbError.Append("Please enter Patient's First Name");
                }
                if (newpatient.Patient_Last_Name == string.Empty)
                {
                    isValidEmp = false;
                    sbError.Append("Please enter Patient's Last Name");
                }
              
                //Checking patient ph.no that it should be 10 digits
                if (newpatient.Patient_PhoneNumber < 1000000000 || newpatient.Patient_PhoneNumber > 9999999999)
                {
                    sbError.Append("Phone Number should be 10 digits long\n");
                    isValidEmp = false;
                }
                //Checking patient pincode that it should be 6 digits
                if (newpatient.Patient_PinCode < 100000 || newpatient.Patient_PinCode > 999999)
                {
                    sbError.Append("Pincode should be 6 digits long\n");
                    isValidEmp = false;
                }
                if (!isValidEmp) throw new PatientException(sbError.ToString());
            }
            catch (PatientException ex)
            { throw ex; }

            return isValidEmp;
        }

    }


}
