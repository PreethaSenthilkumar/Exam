﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HMS.EXCEPTION
{
    /// <summary>
    /// Employee ID : 161261
    /// Employee Name : Preetha Senthilkumar
    /// Description : The class is used for handling patient specific exceptions (EXCEPTION LIBRARY)
    /// Date of Creation : 17.10.2018
    /// </summary>
    public class PatientException : ApplicationException
    {
        //Default constructor
        public PatientException() : base()
         { }

        //Parameterized constructor with message parameter
        public PatientException(string Message) : base(Message)
        { }

    }
}

