 
 --PATIENT_HOSPIATLMANAGEMENTSYSTEM_SQL_QUERY
 
 --Create a new table...Patient
 create table Preetha.Patient_HMS
 (
 Patient_Id int identity(1000,1) primary key,
 Patient_FirstName varchar(20),
 Patient_LastName varchar(20),
 Patient_Gender varchar(7),
 Patient_Address varchar(50),
 Patient_City varchar(20),
 Patient_State varchar(20),
 Patient_Pincode bigint,
 Patient_Phone bigint
 )
 
 --insert values into table
 insert into Preetha.Patient_HMS values('Preetha','Senthilkumar','Female','ADDR1','CBE','TN',641045,9043567891)
 insert into Preetha.Patient_HMS values('Sai','Ram','Male','ADDR2','PLL','AP',641085,9034567891)
  insert into Preetha.Patient_HMS values('Sanjay','Prasath','Male','ADDR3','DSA','Maharastra',641785,9034887891)
   insert into Preetha.Patient_HMS values('Minu','Reshma','Female','ADDR4','PS','Maharastra',641075,9034544891)
 
 --display all records from table
 select * from Preetha.Patient_HMS


 --Add new records of patient details procedure..
CREATE proc [Preetha].[usp_AddPatientProcedure]
 @p_FirstName varchar(20),
 @p_LastName varchar(20),
 @p_Gender varchar(7),
 @p_Address varchar(50),
 @p_City varchar(20),
 @p_State varchar(20),
 @p_Pincode bigint,
 @p_Phone bigint


AS
BEGIN
insert into  Preetha.Patient_HMS 
values(@p_FirstName,@p_LastName ,@p_gender, @p_Address, @p_City, @p_State ,@p_Pincode, @p_Phone)
END


--display available records to the condition specified..
ALTER proc [Preetha].[usp_DisplayPatientProcedure]
as
begin
select * from  Preetha.Patient_HMS
end


select IDENT_CURRENT('Preetha.Patient_HMS')+ident_incr('Preetha.Patient_HMS')

