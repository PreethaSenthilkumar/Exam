﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace PATIENT_DB_FIRST_APPROACH
{
    /// <summary>
    /// Employee ID : 161261
    /// Employee Name : Preetha Senthilkumar
    /// Interaction logic for MainWindow.xaml
    /// Date of Creation : 17.10.2018
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void btn_display_Click(object sender, RoutedEventArgs e)
        {
            Sep19CHNEntities contextObj = new PATIENT_DB_FIRST_APPROACH.Sep19CHNEntities();

           // if (txt_patientstatename.Text != string.Empty)
            
                //query the loaction oriented detials...with where keword...predicate
                var query = from Patient_HMS patient in contextObj.Patient_HMS
                            where patient.Patient_State == txt_patientstatename.Text
                            select patient;
            
           
            List<Patient_HMS> plist = new List<PATIENT_DB_FIRST_APPROACH.Patient_HMS>();
            plist = query.ToList<Patient_HMS>();
            if (plist.Count <= 0) { MessageBox.Show("No records found"); }

          
            else
            {
                dgpatient.ItemsSource = plist;
            }
        }
    }
}
