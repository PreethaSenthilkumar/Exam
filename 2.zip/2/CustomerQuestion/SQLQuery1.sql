
 --Create Customer details table
create table Preetha.CustomerDetailsTable
(
c_id int identity(1000,1) primary key,
c_name varchar(30),
c_address varchar(30),
c_landmark varchar(20),
c_city varchar(20),
c_pincode int,
c_contact bigint,
c_email varchar(30)
)

insert into Preetha.CustomerDetails values('Atulya','Kolar','HP Petrolpump', 'Bhopal', 462042, 7769942667, 'atulya@gmail.com')
insert into Preetha.CustomerDetails values('Jenice','Kolar','HP Petrolpump', 'Mumbai', 562042, 9569948667, 'jenice@gmail.com')
insert into Preetha.CustomerDetails values('Akshara','Kolar','HP Petrolpump', 'Bhopal', 462042, 9561448667, 'akshara@gmail.com')
insert into Preetha.CustomerDetails values('Aparna','Kolar','HP Petrolpump', 'Pune', 561442, 9569914667, 'aparna@gmail.com')
insert into Preetha.CustomerDetails values('Prachi','Kolar','HP Petrolpump', 'Mumbai', 562042, 9560148667, 'prachi@gmail.com')
insert into Preetha.CustomerDetails values('Alice','Kolar','HP Petrolpump', 'Chennai', 595042, 9547548667, 'alice@gmail.com')

select * from Preetha.CustomerDetails

DELETE FROM Preetha.CustomerDetails

DROP TABLE Preetha.CustomerDetails

--create another new table
create table Preetha.CustomerDetailsTables1
(
CustomerID int identity(1000,1),
CustomerName varchar(30),
CustomerAddress varchar(30),
Landmark varchar(20),
City varchar(20),
Pincode int,
Contact bigint,
EmailID varchar(30)
)

--add procedure
 create proc Preetha.usp_AddCustomerDetails
 @c_name varchar(30),
 @c_address varchar(30),
 @c_landmark varchar(20),
 @c_city varchar(20),
 @c_pincode int,
 @c_contact bigint,
 @c_email varchar(20) 
 AS
 BEGIN
 insert into Preetha.CustomerDetails values(@c_name,@c_address,@c_landmark,@c_city,@c_pincode,@c_contact,@c_email)
 END 

 --display procedure
 create proc Preetha.usp_DisplayCustomerDetails
 AS
 BEGIN
 select * from Preetha.CustomerDetails 
 END 

Exec Preetha.usp_DisplayCustomerDetails

--search procdeure
create proc Preetha.usp_GetCustomerId
@c_id int 
AS
BEGIN
select * from Preetha.CustomerDetails
END