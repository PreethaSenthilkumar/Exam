﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
using GKK_Entity;
using GKK_Exceptions;

namespace GKK_DAL
{
    public class Customer_Operations
    {
        /// <summary>
        /// Employee ID : 161698
        /// Employee Name : Apoorva Nath
        /// Description : This class will provide CRUD operations for Customer
        /// Date of Modification : 17th Oct 2018
        /// </summary>

        static string custConnStr = ConfigurationManager.ConnectionStrings["conStr"].ToString();
        static SqlConnection custConnObj;
        SqlCommand custCommand;
        DataTable dtCust;
        SqlDataReader custReader = null;

        public Customer_Operations()
        {
            custConnObj = new SqlConnection();
            custConnObj.ConnectionString = custConnStr;
        }


        public DataTable LoadDeparment()
        {

            try
            {
                dtCust = new DataTable();
                custCommand = new SqlCommand("Apoorva.usp_DisplayCustomerDetails", custConnObj);
                custCommand.CommandType = CommandType.StoredProcedure;
                custConnObj.Open();
                custReader = custCommand.ExecuteReader();
                dtCust.Load(custReader);

            }
            catch (SqlException)
            {
                throw;

            }
            catch (Exception)
            {

                throw;
            }
            finally
            {
                custReader.Close();
                if (custConnObj.State == ConnectionState.Open) custConnObj.Close();
            }
            return dtCust;
        }


        public int AddCustomer_DAL(Customer_Entity cust)
        {
            int rowsAffected = 0;
            try
            {
                custCommand = new SqlCommand("Apoorva.usp_AddCustomerDetails", custConnObj);
                custCommand.CommandType = CommandType.StoredProcedure;      //@c_name,@c_address,@c_landmark,@c_city,@c_pincode,@c_contact,@c_email
                custCommand.Parameters.AddWithValue("@c_name", cust.CustomerName);
                custCommand.Parameters.AddWithValue("@c_address", cust.CustomerAddress);
                custCommand.Parameters.AddWithValue("@c_landmark", cust.Landmark);
                custCommand.Parameters.AddWithValue("@c_city", cust.City);
                custCommand.Parameters.AddWithValue("@c_pincode", cust.Pincode);
                custCommand.Parameters.AddWithValue("@c_contact", cust.ContactNo);
                custCommand.Parameters.AddWithValue("@c_email", cust.EmailID);
                custConnObj.Open();
                rowsAffected = custCommand.ExecuteNonQuery();

            }
            catch (SqlException)
            {
                throw;
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                if (custConnObj.State == ConnectionState.Open) custConnObj.Close();
            }
            return rowsAffected;
        }
       
        public DataTable DisplayCustomer_DAL()
        {
            try
            {
                dtCust = new DataTable();
                custCommand = new SqlCommand("Apoorva.usp_DisplayCustomerDetails", custConnObj);
                custCommand.CommandType = CommandType.StoredProcedure;
                custConnObj.Open();
                custReader = custCommand.ExecuteReader();
                if (custReader.HasRows)
                {
                    dtCust.Load(custReader);
                }
            }
            catch (SqlException)
            {
                throw;
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                custReader.Close();
                if (custConnObj.State == ConnectionState.Open) custConnObj.Close();
            }
            return dtCust;
        }

        public DataTable GetCustomerByID_DAL(int cust_id)
        {
            try
            {
                dtCust = new DataTable(/*int cust_id*/);
                custCommand = new SqlCommand("Manish.usp_SearchEmployeeDept", custConnObj);
                custCommand.CommandType = CommandType.StoredProcedure;
                custCommand.Parameters.AddWithValue("@c_id", cust_id);
                custConnObj.Open();
                custReader = custCommand.ExecuteReader();
                if (custReader.HasRows)
                {
                    dtCust.Load(custReader);
                }
            }
            catch (SqlException)
            {

                throw;
            }
            catch (Exception)
            {

                throw;
            }
            finally
            {
                custReader.Close();
                if (custConnObj.State == ConnectionState.Open) custConnObj.Close();
            }
            return dtCust;
        }
    }
}