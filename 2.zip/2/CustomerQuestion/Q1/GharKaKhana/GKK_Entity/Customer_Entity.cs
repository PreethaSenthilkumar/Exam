﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GKK_Entity
{
    /// <summary>
    /// Employee ID : 161698
    /// Employee Name : Apoorva Nath
    /// Description : This is an Entity Class for Customer
    /// Date of Modification : 17th Oct 2018
    /// </summary>

    public class Customer_Entity
    {
        //Get or Set Customer ID
        public int CustomerID { get; set; }

        //Get or Set Customer Name
        public string CustomerName { get; set; }

        //Get or Set Customer Address
        public string CustomerAddress { get; set; }

        //Get or Set Landmark
        public string Landmark { get; set; }

        //Get or Set City
        public string City { get; set; }

        //Get or Set Pincode
        public int Pincode { get; set; }

        //Get or Set Contact Number
        public long ContactNo { get; set; }

        //Get or Set Enail Id
        public string EmailID { get; set; }        
    }
}
