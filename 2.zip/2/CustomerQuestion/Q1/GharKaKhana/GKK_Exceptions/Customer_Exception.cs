﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GKK_Exceptions
{
    /// <summary>
    /// Employee ID : 161698
    /// Employee Name : Apoorva Nath
    /// Description : This is an user defined exception class for a Customer
    /// Date of Modification : 17th Oct 2018
    /// </summary>

    public class Customer_Exception : ApplicationException
    {
        public Customer_Exception() : base()
        { }

        public Customer_Exception(string Message) : base(Message)
        { }
    }
}
