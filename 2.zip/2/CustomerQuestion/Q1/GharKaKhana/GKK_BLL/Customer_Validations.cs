﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
using GKK_Entity;
using GKK_Exceptions;
using GKK_DAL;

namespace GKK_BLL
{
    /// <summary>
    /// Employee ID : 161698
    /// Employee Name : Apoorva Nath
    /// Description : This class will have business logic for Customer
    /// Date of Modification : 17th Oct 2018
    /// </summary>

    public class Customer_Validations
    {
        Customer_Operations custOperation;
        public DataTable LoadDeparment_BLL()
        {
            DataTable dtCust;
            try
            {
                custOperation = new Customer_Operations();
                dtCust = custOperation.LoadDeparment();
            }
            catch (SqlException se)
            {
                throw se;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return dtCust;
        }     
        
        //validate customer
        public bool validateCust(Customer_Entity newCust)
        {
            bool isValidCust = true;
            StringBuilder sbError = new StringBuilder();
            try
            {   //Checking employee name
                if (newCust.CustomerName == string.Empty)
                {
                    isValidCust = false;
                    sbError.Append("Customer Name cannot be blank");
                }
                else if (!Regex.IsMatch(newCust.CustomerName, "[A-Z][a-z]{2,}"))
                    {
                        isValidCust = false;
                        sbError.Append("Customer Name can only contain alphabets and spaces with atleast 3 characters.\n");                     
                    }
                if (!isValidCust) throw new Customer_Exception(sbError.ToString());

                //Checking Address
                if (newCust.CustomerAddress == string.Empty)
                {
                    isValidCust = false;
                    sbError.Append("Address cannot be blank");
                }
                if (!isValidCust) throw new Customer_Exception(sbError.ToString());

                //Checking Landmark
                if (newCust.Landmark == string.Empty)
                {
                    isValidCust = false;
                    sbError.Append("Landmark cannot be blank");
                }
                if (!isValidCust) throw new Customer_Exception(sbError.ToString());

                //Checking City
                if (newCust.City == string.Empty)
                {
                    isValidCust = false;
                    sbError.Append("City cannot be blank");
                }
                if (!isValidCust) throw new Customer_Exception(sbError.ToString());

                //Checking Pincode
                if (newCust.Pincode == 0)
                {
                    isValidCust = false;
                    sbError.Append("Pincode cannot be blank and should have exactly 6 digits");
                }
                if (!isValidCust) throw new Customer_Exception(sbError.ToString());

                //Checking Contact Number
                if (newCust.ContactNo == 0)
                {
                    isValidCust = false;
                    sbError.Append("Contact Number cannot be blank and should have exactly 10 digits");
                }
                if (!isValidCust) throw new Customer_Exception(sbError.ToString());

                //Checking Email ID
                if (newCust.EmailID == string.Empty)
                {
                    isValidCust = false;
                    sbError.Append("Email ID cannot be blank");
                }
                if (!isValidCust) throw new Customer_Exception(sbError.ToString());
            }
            catch (Customer_Exception ex)
            { throw ex; }

            return isValidCust;           
        }

        // Get customer
        public DataTable DisplayCustomer_BLL()
        {
            DataTable dtCust;
            try
            {
                custOperation = new Customer_Operations();
                dtCust = custOperation.DisplayCustomer_DAL();
            }
            catch (SqlException se)
            {
                throw se;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return dtCust;
        }

        //Add customer
        public int AddCustomer_BLL(Customer_Entity newCust)
        {
            int rowsAffected = 0;
            Customer_Operations operationObj;
            try
            {
                if (validateCust(newCust))
                {
                    operationObj = new Customer_Operations();
                    rowsAffected = operationObj.AddCustomer_DAL(newCust);
                }
            }
            catch (Customer_Exception ex) { throw ex; }
            catch (SqlException se) { throw se; }
            catch (Exception ex) { throw ex; }
            return rowsAffected;
        }        
    }
}
