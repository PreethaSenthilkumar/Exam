﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace CustomerDetailsDBFirst
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void btn_Display_Click(object sender, RoutedEventArgs e)
        {
            Sep19CHNEntities2 contextObj = new Sep19CHNEntities2();

            if (txt_custLoc.Text != string.Empty)
            {
                var query1 = from CustomerDetail cust1 in contextObj.CustomerDetails
                             where cust1.c_city == txt_custLoc.Text
                             select cust1;

                List<CustomerDetail> clist1 = new List<CustomerDetail>();
                clist1 = query1.ToList<CustomerDetail>();
                if (clist1.Count <= 0)
                {
                    MessageBox.Show("No Records found!!");
                }
                else
                {
                    dg_Cust.ItemsSource = query1.ToList();
                }
            }
            else MessageBox.Show("Please enter City!");
        }
    }
}
