﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace Application1
{
    public partial class InsertStudent : System.Web.UI.Page
    {
        
        protected void Page_Load(object sender, EventArgs e)
        {
           

        }

        protected void btnInsert_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["Training"].ConnectionString);
            SqlCommand cmd = new SqlCommand("INSERT INTO StudentsuryaTable(Student_Name,Department_Code,Student_Dob,Student_Address) VALUES (@SName,@DCode,@DOB,@Address)", con);
            //cmd.Parameters.AddWithValue("@SCode", txtCode.Text);
            cmd.Parameters.AddWithValue("@SName", txtName.Text);
            cmd.Parameters.AddWithValue("@DCode",Convert.ToInt32( txtDCode.Text));
            cmd.Parameters.AddWithValue("@DOB", Convert.ToDateTime(txtDob.Text));
            cmd.Parameters.AddWithValue("@Address", txtAddress.Text);

            con.Open();
            int recordsAffected = Convert.ToInt32(cmd.ExecuteNonQuery());
            con.Close();
            if (recordsAffected > 0)
            {
                
                Response.Write("<SCRIPT type='text/javascript'>alert('Student Data inserted successfully');</SCRIPT>");
            }
            else
            {
                Response.Write("<SCRIPT type='text/javascript'>alert('Student Data not updated');</SCRIPT>");
            }
        }
    }
}