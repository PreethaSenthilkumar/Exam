
create table StudentsuryaTable
(
Student_Code int identity(1000,1000) primary key,
Student_Name varchar(40),
Department_Code int,
Student_Dob datetime,
Student_Address varchar(40)
)

Delete from Studentsuryaaa

insert into StudentsuryaTable values('Preetha','10','4/08/1996','Hyderabad')
insert into StudentsuryaTable values('Reshma','20','10/11/1995','Chennai')
insert into StudentsuryaTable values('Krish','30','6/09/1997','Bangalore')

select * from StudentsuryaTable