 --ONLINE_EVALUATION_SYSTEM_SQL_QUERY
 
 --Create a new table...Trainer's Perfromanace:

create table Preetha.Trainee_Perfromance
(
Employee_ID int identity(101,1),
Module_Name varchar(40),
Batch_name varchar(30),
Comments varchar(60),
)

--inserting values(Performance Details) into the database...
insert into Preetha.Trainee_Perfromance values('MODULE A: DOTNET','SEPT DOTNET BATCH','Good..')
insert into Preetha.Trainee_Perfromance values('MODULE B: ADO','SEP DOTNET BATCH','Need Improvements')
insert into Preetha.Trainee_Perfromance values('MODULE C: JEE FULLSTACK','AUG JEE BATCH','No Comments')
insert into Preetha.Trainee_Perfromance values('MODULE B: MAINFRAME','NOV MF BATCH','Good..')

--Display the entire table
select * from Preetha.Trainee_Perfromance


--Add Entry
--Add procedure to add trainee performance into the table
 create proc Preetha.usp_Add_Trainee_Performance_Procedure
 --@eEmployee_ID int,
 @eModule_Name varchar(40),
 @eBatch_name varchar(30),
 @eComments varchar(60)

 AS
 BEGIN
 insert into Preetha.Trainee_Perfromance values(@eModule_Name,@eBatch_name,@eComments)
 END


 --display available records to the condition specified..
CREATE proc Preetha.usp_Display_Trainee_Performance_Procedure
 AS
 BEGIN
	
 END

select IDENT_CURRENT('Preetha.Trainee_Perfromance')+ident_incr('Preetha.Trainee_Perfromance')