﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using OES.ENTITY;   //Reference to Entity Library
using OES.EXCEPTION; //Reference to Exception Library

namespace OES.DAL
{
    /// <summary>
    /// patientloyee ID : 161261
    /// patientloyee Name : Preetha Senthilkumar
    /// Description : This class will provide the CRUD operations for the Trainee_Perfromance (DAL LIBRARY)
    /// Date of Creation : 17.10.2018
    /// </summary>
    public class Trainee_Perfromance_Operation
    {
        static string traineeConnStr = ConfigurationManager.ConnectionStrings["conStr"].ToString();
        static SqlConnection traineeConnObj;
        SqlCommand traineeCommand;
        DataTable dtDept, dtTrainee;
        SqlDataReader traineeReader = null;

        public Trainee_Perfromance_Operation()
        {
            traineeConnObj = new SqlConnection();
            traineeConnObj.ConnectionString = traineeConnStr;
        }

        public DataTable LoadDeparment()
        {

            try
            {
                dtDept = new DataTable();
                traineeCommand = new SqlCommand("Preetha.usp_Display_Trainee_Performance_Procedure", traineeConnObj);
                traineeCommand.CommandType = CommandType.StoredProcedure;
                traineeConnObj.Open();
                traineeReader = traineeCommand.ExecuteReader(); GetEmployee_DAL();
                dtDept.Load(traineeReader);
            }
            catch (SqlException)
            {
                throw;

            }
            catch (Exception)
            {

                throw;
            }
            finally
            {
                traineeReader.Close();
                if (traineeConnObj.State == ConnectionState.Open) traineeConnObj.Close();
            }
            return dtDept;
        }

        public DataTable GetEmployee_DAL()
        {
            try
            {
                dtTrainee = new DataTable();
                 traineeCommand = new SqlCommand("Preetha.usp_Display_Trainee_Performance_Procedure", traineeConnObj);
                traineeCommand.CommandType = CommandType.StoredProcedure;
                traineeConnObj.Open();
                traineeReader = traineeCommand.ExecuteReader();
                if ( traineeReader.HasRows)
                {
                    dtTrainee.Load(traineeReader);
                }
            }
            catch (SqlException)
            {

                throw;
            }
            catch (Exception)
            {

                throw;
            }
            finally
            {
                traineeReader.Close();
                if (traineeConnObj.State == ConnectionState.Open) traineeConnObj.Close();
            }
            return dtTrainee;
        }

        //Adds the patient records into the table...procedure
        public int Add_Trainee_DAL(Trainee_Performance_Class trainee)
        {
            int rowsAffected = 0;
            try
            {

                //Adding parameters to command
                traineeCommand = new SqlCommand("Preetha.usp_Add_Trainee_Performance_Procedure", traineeConnObj);
                traineeCommand.CommandType = CommandType.StoredProcedure;//,@eLoc,@ePh,@eDeptId
                traineeCommand.Parameters.AddWithValue("@eModule_Name", trainee.Module_Name);
                traineeCommand.Parameters.AddWithValue("@eBatch_name", trainee.Batch_Name);
                traineeCommand.Parameters.AddWithValue("@eComments", trainee.Comments);
             
                //Executing command
                traineeConnObj.Open();
                rowsAffected = traineeCommand.ExecuteNonQuery();

            }
            catch (SqlException)
            {

                throw;
            }
            catch (Exception)
            {

                throw;
            }
            finally
            {
                if (traineeConnObj.State == ConnectionState.Open) traineeConnObj.Close();
            }
            return rowsAffected;

        }
    }
}
