﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OES.ENTITY
{
    /// <summary>
    /// Employee ID : 161261
    /// Employee Name : Preetha Senthilkumar
    /// Description : This is entity class for the Trainee_Performance information (ENTITY LIBRARY)
    /// Date of Creation : 27.10.2018
    /// </summary>
    
    public class Trainee_Performance_Class
    {
        //Define the properties using getters and setters property method...
        public int Employee_ID{ get; set; }
        public string Module_Name { get; set; }
        public string Batch_Name { get; set; }
        public string Comments{ get; set; }
    }
}
