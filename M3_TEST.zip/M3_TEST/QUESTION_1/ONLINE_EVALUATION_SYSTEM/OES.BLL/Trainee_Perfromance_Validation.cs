﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;//use/import regular expression fro validation
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using OES.ENTITY;
using OES.EXCEPTION;
using OES.DAL;

namespace OES.BLL
{
    public class Trainee_Perfromance_Validation
    {
        Trainee_Perfromance_Operation traineeOperation;
        public DataTable LoadDeparment_BLL()
        {
            DataTable dtDept;
            try
            {
                traineeOperation = new Trainee_Perfromance_Operation();
                dtDept = traineeOperation.LoadDeparment();
            }
            catch (SqlException se)
            {

                throw se;
            }
            catch (Exception ex)
            {

                throw ex;
            }
            return dtDept;
        }

        public DataTable GetEmployee_BLL()
        {
            DataTable dtTrainee;
            try
            {
                traineeOperation = new Trainee_Perfromance_Operation();
                dtTrainee = traineeOperation.GetEmployee_DAL();
            }
            catch (SqlException se)
            {

                throw se;
            }
            catch (Exception ex)
            {

                throw ex;
            }
            return dtTrainee;
        }

        //validate  Trainee
        public bool validatetrainee(Trainee_Performance_Class newtrainee)
        {
            bool isValidtrainee = true;
            StringBuilder sbError = new StringBuilder();
            try
            {
                //Employee ID Validation...
                //if (newtrainee.Employee_ID <= 0)
                //{
                //   isValidtrainee = false;
                //    sbError.Append("Employee ID should be greater than 0\n");
                //}
                //Module Name Validation..
                if (newtrainee.Module_Name == string.Empty)
                {
                    isValidtrainee = false;
                    sbError.Append("Module Name cannot be Empty. Please enter the apt Module Name");
                }
                else if (!Regex.IsMatch(newtrainee.Module_Name, "[A-Z][a-z]+"))
                {
                    isValidtrainee = false;
                    sbError.Append("Module name should have alphabets only\n");
                }
                if (!isValidtrainee) throw new Trainee_Performance_Exception(sbError.ToString());
                 
                //Batch Name Validation
                if (newtrainee.Batch_Name == string.Empty)
                {
                    isValidtrainee = false;
                    sbError.Append("Batch Name cannot be Empty. Please enter the apt Batch Name");
                }
                else if (!Regex.IsMatch(newtrainee.Batch_Name, "[A-Z][a-z]+"))
                {
                    isValidtrainee = false;
                    sbError.Append("Batch name should have alphabets only\n");
                }
                if (!isValidtrainee) throw new Trainee_Performance_Exception(sbError.ToString());
                //Comments Validation..
                if (newtrainee.Comments == string.Empty)
                {
                    isValidtrainee = false;
                    sbError.Append("Comments field cannot be Empty. Please enter the required Comments");
                }
                else if (!Regex.IsMatch(newtrainee.Comments, "[A-Z][a-z]+"))
                {
                    isValidtrainee = false;
                    sbError.Append("Comments should have alphabets only\n");
                }
                if (!isValidtrainee) throw new Trainee_Performance_Exception(sbError.ToString());

            }
            catch (Trainee_Performance_Exception ex)
            { throw ex; }

            return isValidtrainee;
        }


        //Add employee
        public int AddEmployee_BLL(Trainee_Performance_Class newtrainee)
        {
            int rowsAffected = 0;
            Trainee_Perfromance_Operation operationObj;
            try
            {
                if (validatetrainee(newtrainee))
                {
                    operationObj = new Trainee_Perfromance_Operation();
                    rowsAffected = operationObj.Add_Trainee_DAL(newtrainee);
                }
            }
            catch (Trainee_Performance_Exception ex) { throw ex; }
            catch (SqlException se) { throw se; }
            catch (Exception ex) { throw ex; }
            return rowsAffected;

        }
    }
}
