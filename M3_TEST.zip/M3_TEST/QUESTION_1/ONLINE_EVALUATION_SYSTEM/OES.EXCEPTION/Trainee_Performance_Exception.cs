﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OES.EXCEPTION
{
    /// <summary>
    /// Employee ID : 161261
    /// Employee Name : Preetha Senthilkumar
    /// Description : The class is used for handling Trainee_Performance specific exceptions (EXCEPTION LIBRARY)
    /// Date of Creation : 27.10.2018
    /// </summary>

    public class Trainee_Performance_Exception : ApplicationException // Trainee_Performance_Exception inherits/extends from ApplicationException
    {
            //Default constructor
            public Trainee_Performance_Exception() : base()
            { }

            //Parameterized constructor with message parameter
            public Trainee_Performance_Exception(string Message) : base(Message)
            { }

        }
}
