﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace TRAINEE_DB_FIRST_APPROACH
{ 
    /// <summary>
  /// Employee ID : 161261
  /// Employee Name : Preetha Senthilkumar
  /// Interaction logic for MainWindow.xaml
  /// Date of Creation : 27.10.2018
  /// </summary>
  /// 
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void btn_display_Click(object sender, RoutedEventArgs e)
        {
            Sep19CHNEntities contextObj = new TRAINEE_DB_FIRST_APPROACH.Sep19CHNEntities();

            // if (txt_patientstatename.Text != string.Empty)

            //query the loaction oriented detials...with where keword...predicate
            var query = from Trainee_Perfromance trainee in contextObj.Trainee_Perfromance
                        where trainee.Module_Name == txt_Module.Text
                        select trainee;


            List<Trainee_Perfromance> plist = new List<TRAINEE_DB_FIRST_APPROACH.Trainee_Perfromance>();
            plist = query.ToList<Trainee_Perfromance>();
            if (plist.Count <= 0) { MessageBox.Show("No records found"); }


            else
            {
                dgtrainee.ItemsSource = plist;
            }
        }
    }
}
